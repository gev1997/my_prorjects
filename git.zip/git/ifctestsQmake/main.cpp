#include <QApplication>
#include <QWidget>
#include <QDebug>
#include <iostream>

#include <ifcpp/reader/ReaderSTEP.h>
#include <ifcpp/IFC4/include/IfcBuildingStorey.h>
#include <ifcpp/geometry/Carve/GeometryConverter.h>

#include <ifcpp/geometry/Carve/ConverterOSG.h>
#include <ifcpp/IFC4/include/IfcBuildingStorey.h>

using std::cerr;

int main(int argc, char *argv[]) {
    //QApplication a(argc, argv);
    //QWidget w;

    shared_ptr<BuildingModel> building_model(new BuildingModel);
    shared_ptr<ReaderSTEP> reader_step(new ReaderSTEP);
    reader_step->loadModelFromFile(L"model.ifc", building_model);

    shared_ptr<GeometryConverter> geometry_converter
            = std::make_shared<GeometryConverter>(building_model);

    std::map<int, shared_ptr<BuildingEntity>>& building_entities
            = building_model->getMapIfcEntities();

    shared_ptr<IfcBuildingStorey> ifc_project(new IfcBuildingStorey);
    for (auto i : building_entities) {
        if (i.second->className() == ifc_project->className()) {
            std::cout << i.first << " " << i.second->className() << std::endl;
        }
    }

    geometry_converter->convertGeometry();

    // osg::ref_ptr<osg::Switch> m_sw_model = new osg::Switch();
    // m_sw_model->setName( "m_sw_model" );
    // shared_ptr<ConverterOSG> converter_osg(new ConverterOSG(geometry_converter->getGeomSettings()));
    // converter_osg->setMessageTarget(geometry_converter.get());
    // converter_osg->convertToOSG(geometry_converter->getShapeInputData(), m_sw_model);

    //std::map<std::string, shared_ptr<ProductShapeData> shape_data_m = geometry_converter->getShapeInputData();

    //std::vector<shared_ptr<AppearanceData>> app_data_vec = shape_data_map.begin().second->getAppearances();

    // for (auto i : shape_data_map) {
    //     auto it = shape_data_map.begin();
    //     for (auto j : it->second->m_vec_representations) {
    //         for (auto k : j->m_vec_item_data) {
    //             for (auto g : k->m_meshsets) {
    //                 for (auto h : g->meshes) {
    //                     for (auto face : h->faces) {
    //                         carve::mesh::Edge<3>* edge = face->edge;

    //                         for (int i = 0; i < (int)face->nEdges(); ++i) {
    //                             carve::geom::vector<3> vv = it->second->getTransform() * edge->vert->v;
    //                             //cerr << vv.x << " " << vv.y << " " << vv.z << std::endl;
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //     }
    // }

    

    // cerr << geometry_converter->getShapeInputData().size();

    // shared_ptr<IfcProject> ifc_project = building_model->getIfcProject();
    // std::vector<std::pair<std::string, shared_ptr<BuildingObject>>> vec_attributes;
    // ifc_project->getAttributes(vec_attributes);

    // for (auto i : vec_attributes) {
    //     std::cout << i.first << std::endl;

    //     std::vector<std::pair<std::string, shared_ptr<BuildingObject>>> attr;
    //     i.second->getAttributes(attr);

    //     for (auto j : attr) {
    //         std::cout << j.first << std::endl;
    //     }
    // }



//    std::map<std::string, std::shared_ptr<ProductShapeData>> p_shape_data
//            = geometry_converter->getShapeInputData();




//    std::string guid = ifc::get_global_id(entity);
//    auto it = sd.find(guid);
//    carve::math::Matrix global_matrix = get_transform_data(entity);
//    std::shared_ptr<ProductShapeData> pd = it->second;
//    std::string guid = ifc::get_global_id(entity);
//    auto it = sd.find(guid);
//    assert(! (it == sd.end()));
//    carve::math::Matrix global_matrix = get_transform_data(entity);
//    std::shared_ptr<ProductShapeData> pd = it->second;
//    assert(nullptr != pd);
//    QVector<QVector<QVector3D>> mesh;
//    using RD = std::shared_ptr<RepresentationData>;
//    using ISD = std::shared_ptr<ItemShapeData>;

    //w.show();
    return 0;
}
