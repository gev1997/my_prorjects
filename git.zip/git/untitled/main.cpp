#include "QMainWindow"

#include <QApplication>
#include <QWidget>
#include <QDockWidget>

#include <QTreeWidget>
#include <QTreeWidgetItem>

#include <ifcpp/reader/ReaderSTEP.h>
#include <
int main(int argc, char *argv[]) {
	QApplication a(argc, argv);
	QMainWindow* w = new QMainWindow();
	w->setFixedSize(800, 800);

	QDockWidget* dw = new QDockWidget(w);
	dw->setFixedSize(350, 500);
	
	QTreeWidget* tree = new QTreeWidget(dw);
	tree->setFixedSize(300, 200);
	tree->setColumnCount(3);
	tree->setHeaderLabels({"Project", "Name", "Description"});

	// QTreeWidget* tree2 = new QTreeWidget(w);
	// // tree2->setFixedSize(300, 200);
	// tree2->setGeometry(0, 100, 300, 200);

	ReaderSTEP* r = new ReaderSTEP();

	QTreeWidgetItem* item1 = new QTreeWidgetItem(tree, {"2", "a", "b"});
	QTreeWidgetItem* item1_1 = new QTreeWidgetItem(item1, {"h", "e", "l"});
	QTreeWidgetItem* item1_2 = new QTreeWidgetItem(item1);
		//item1_1->text("hello");

	QTreeWidgetItem* item2 = new QTreeWidgetItem(tree, {"2"});
	QTreeWidgetItem* item2_1 = new QTreeWidgetItem(item2, {"1"});
	QTreeWidgetItem* item2_2 = new QTreeWidgetItem(item2, {"1"});

	QTreeWidgetItem* item3 = new QTreeWidgetItem(tree, {"3"});
	QTreeWidgetItem* item3_1 = new QTreeWidgetItem(item3, {"1"});
	QTreeWidgetItem* item3_2 = new QTreeWidgetItem(item3, {"1"});

	w->show();
	return a.exec();
}
