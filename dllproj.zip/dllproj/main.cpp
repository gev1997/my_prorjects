
#include "shared_lib.h"

int main() {
    print();


    std::cin.get();
    std::cin.get();
    return 0;
}