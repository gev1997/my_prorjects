#ifndef SHARED_LIB_H
#define SHARED_LIB_H

#include <iostream>
//#include <cstdlib>
#include <stdio.h>

#ifdef __cplusplus
    extern "C" {
#endif        
 
    #ifdef BUILD_MY_DLL
        #define SHARED_LIB __declspec(dllexport)
    #else
        #define SHARED_LIB __declspec(dllimport)
    #endif

    void SHARED_LIB print();

#ifdef __cplusplus
    }
#endif

#endif //SHARED_LIB_H