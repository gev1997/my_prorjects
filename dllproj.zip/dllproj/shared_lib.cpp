#include "shared_lib.h"

void print() {
    std::cout << "hello dll";
}