#include "qcube.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    QCube cubeWindow;

    cubeWindow.resize(600, 600);
    cubeWindow.show();

    return a.exec();
}
