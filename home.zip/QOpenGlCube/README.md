# 3D Cube in OpenGl

3D հարթությունում խորանարդ նկարելու համար, մենք կօգտվենք Qt ծրագրից։

<p><img src="cube.png"><img src="cube2.png"></p>

Qt֊ում OpenGl֊ից օգտվելու համար, պետք է պրոեկտին ավելացնել համապատասխան գրադարանը․

    #include «QOpenGLWidget»

QOpenGLWidget կլասը օգտագործելու համար, պետք է նրանից public ժառանգել և վերասահմանել նրա վիրտուալ
ֆունկցիաներից երեքը՝

    initializeGL()
    resizeGL(GLint, GLint)
    paintGL()

Կլասի նկարագրությունը հետևյալն է

    class QCube : public QOpenGLWidget {
    public:
        QCube(QWidget* pwgt = nullptr);

    protected:
        virtual void initializeGL() override;
        virtual void resizeGL(GLint, GLint) override;
        virtual void paintGL() override;

        virtual void mousePressEvent(QMouseEvent*) override;
        virtual void mouseMoveEvent(QMouseEvent*) override;
        virtual void wheelEvent(QWheelEvent*) override;

        GLuint draw_cube(GLfloat);

    private:
        GLuint m_nCube;
        GLfloat m_xRotate;
        GLfloat m_yRotate;
        QPoint m_ptPosition;

        GLfloat m_scale;
        bool m_is_line;

        QVector<GLfloat> m_vertices = {
            -1.0f, 1.0f, 1.0f,
            1.0f, 1.0f, 1.0f,
            1.0f, -1.0f, 1.0f,
            -1.0f, -1.0f, 1.0f,

            1.0f, 1.0f, 1.0f,
            1.0f, 1.0f, -1.0f,
            1.0f, -1.0f, -1.0f,
            1.0f, -1.0f, 1.0f,

            1.0f, 1.0f, -1.0f,
            -1.0f, 1.0f, -1.0f,
            -1.0f, -1.0f, -1.0f,
            1.0f, -1.0f, -1.0f,

            -1.0f, 1.0f, -1.0f,
            -1.0f, 1.0f, 1.0f,
            -1.0f, -1.0f, 1.0f,
            -1.0f, -1.0f, -1.0f,

            -1.0f, 1.0f, 1.0f,
            1.0f, 1.0f, 1.0f,
            1.0f, 1.0f, -1.0f,
            -1.0f, 1.0f, -1.0f,

            -1.0f, -1.0f, 1.0f,
            1.0f, -1.0f, 1.0f,
            1.0f, -1.0f, -1.0f,
            -1.0f, -1.0f, -1.0
            };
    };

#### initializeGL()
Ծրագիրը սկսելուց կանչվում է, և ինիցիալիզացվում մի քանի պարամետր՝

    void QCube::initializeGL() {
        QOpenGLFunctions* pFunc = QOpenGLContext::currentContext()->functions();
        pFunc->glClearColor(0, 0, 0, 1);

        pFunc->glEnable(GL_DEPTH_TEST);

        m_nCube = draw_cube(2);
    }

Սահմանում ենք էկրանի գույնը և միացնում էկրանի խորության ստուգման ռեժիմը։ Պատկերում ենք խորանարդը,
նշված չափսով։


#### resizeGL()
Որպես պարամետր ստանում է էկրանի չափսերը՝ երկարությունը և լայնությունը։

    void QCube::resizeGL(GLint width, GLint height) {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glViewport(0, 0, width, height);

        glFrustum(-1.0, 1.0, -1.0, 1.0, 2, 50.0);
        glTranslatef(0, -1, -15);
    }

Այն կանչվում է այն դեպքում, երբ էկրանի չափսերը փոխում ենք։


#### paintGL()
Այն կանչվում է ամեն անգամ էկրանը թարմացնելուց։

    void QCube::paintGL() {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        if (m_is_line) {
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        } else {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        }

        glTranslatef(0.0, 0.0, -6);
        glRotatef(m_xRotate, 1.0, 0.0, 0.0);
        glRotatef(m_yRotate, 0.0, 1.0, 0.0);
        glScalef(m_scale, m_scale, m_scale);

        glCallList(m_nCube);
    }

Մաքրում ենք էկրանին տպված հին պատկերը, սահմանում է մատրիցի պատկերման ռեժիմը և մատրիցը բերում է սկզբնական վիճակի։
glRotatef ֆունկցիան օգտագործում ենք, մատրիցը պտտելու համար, xRotate և yRotate պարամետրեր են, որոնք օգտագործում ենք
պատկերը պտտելուց, մկնիկի միջոցով։


### draw_cube()
    GLuint QCube::draw_cube(GLfloat s) {
        GLuint n_gen_lists = glGenLists(1);

        glNewList(n_gen_lists, GL_COMPILE);
        drawX();
        drawY();
        drawZ();

        drawAxises();

        DrawArrow('x');
        DrawArrow('y');
        DrawArrow('z');

        glEnableClientState(GL_VERTEX_ARRAY);
            glColor3f(0.5, 0.4, 0.4);
            glVertexPointer(3, GL_FLOAT, 0, m_vertices.data());
            glDrawArrays(GL_QUADS, 0, 24);
        glDisableClientState(GL_VERTEX_ARRAY);

        glEndList();

        return n_gen_lists;
    }

Առաջին տողում glGenLists(1) ֆունկցիան վերադարձնում է ազատ իդենտիֆիկատորի համարը։
Այդ արժեքը պահում ենք n_gen_lists փոփոխականի մեջ։ n_gen_lists֊ի արժեքն էլ իր հերթին վերադարձվում է
draw_cube֊ից, և վերագրվում m_nCube անդամ փոփոխականին, որի արժեքը փոխանցում ենք glCallList֊ին։
glCallList֊ի շնորհիվ արագացնում ենք մարմինների պատկերումը, քանի որ glCallList֊ը օգտվում է նախկինում
կրկին պատկերված և վիդեոպրոցեսորի cache-ում պահված տվյալներից, և ցուցադրում այն, խուսափելով կրկին պատկերելուց։

Ստեղծում ենք նոր լիստ, օգտագործելով իդենտիֆիկատորի համարը։

    glNewList(n_gen_lists, GL_COMPILE);

Պատկերում ենք կողմերը։

    glEnableClientState(GL_VERTEX_ARRAY);
        glColor3f(0.0, 0.4, 0.0);
        glVertexPointer(3, GL_FLOAT, 0, m_vertices.data());
        glDrawArrays(GL_QUADS, 0, 24);
    glDisableClientState(GL_VERTEX_ARRAY);

glColor3f(0.0, 0.4, 0.0) Սահմանում ենք պատկերի գույնը։

glVertexPointer֊ին փոխանցում ենք m_vertices.data(), որը float տիպի զանգված է, որտեղ նշված են կետերի կոորդինատները։

glDrawArrays֊ին հայտնում ենք, թե ինչ ձևի պատկեր ենք ուզում նկարել, օրինակում օգտագործվում է
GL_QUADS, որը իրենից ներկայացնում է քառանկյուն։

glEndList() ֆունկցիան կանչելով հայտնում ենք լիստի պատկերման ավարտը։


### mousePressEvent()
mousePressEvent()֊ը վիրտուալ վերասահմանված ֆունկցիա է, որը կանչվում է ամեն անգամ մկնինի կլիկի ժամանակ։
Որպես պարամետր ստանում է QMouseEvent կլասի event օբյեկտ։ QMouseEvent կլասը ստեղծված է մկնիկից ստացվող տվյալները
մշակելու և օգտագործելու համար։

update() ֆունկցիան կանչում ենք mousePressEvent()֊ից, էկրանը թարմացնելու համար։

Ամեն կլիկի ժամանակ, պահում ենք մկնիկի սլաքի կոորդինատները QPoint տիպի ptPosition օբյեկտում։


### mouseMoveEvent()
mouseMoveEvent()֊ը վիրտուալ վերասահմանված ֆունկցիա է, որը կանչվում է մկնիկի կուրսորը շարժելուց։
Որպես պարամետր ստանում է QMouseEvent կլասի event օբյեկտ։

mouseMoveEvent() ֆունկցիայում ամեն անգամ փոխում ենք xRotate և yRotate պարամետրները, որոնց արժեքներից կախված,
մատրիցը պտտվում է X և Y առանցքների շուրջ։

    xRotate += 180 * (GLfloat)(event->y() - ptPosition.y()) / height();
    yRotate += 180 * (GLfloat)(event->x() - ptPosition.x()) / width();

որտեղ event֊ը դա QMouseEvent տիպի օբյեկտ է, event->x() և event->y() մկնիկի սլաքի կոորդինատներն են,
տվյալ պահինն, իսկ ptPosition մկնիկի սլաքի դրիքն է, կոճակը սեղմելու պահին։

width() և height() համապատասխանաբար էկրանի լայնությունը և բարձրությունը։


## main.cpp

main.cpp compilation unit֊ում ստեղծում ենք QOpenGLWidget կլասից ժառանգած մեր կլասի օբյեկտ։

Փոխում ենք էկրանի չափսերը

    resize(width, height)

 և ցուցադրում էկրանը

    show();
․

    #include "qcube.h"

    #include <QApplication>

    int main(int argc, char *argv[]) {
        QApplication a(argc, argv);

        QCube cubeWindow;

        cubeWindow.resize(900, 900);
        cubeWindow.show();

        return a.exec();
    }
