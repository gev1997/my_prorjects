#include <GL/gl.h>
#include <GL/glut.h>

void initializeGL() {
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);

    glBegin(GL_LINES);
        glColor3f(1, 0, 0);
        
        glVertex2f(0, 0);
        glVertex2f(0.5, 0);
    glEnd();

    glFlush();
    glutSwapBuffers();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_DEPTH);

    glutInitWindowSize(500, 500);
    glutInitWindowPosition(200, 200);
    glutCreateWindow("OpenGL");

    initializeGL();

    glutDisplayFunc(display);
    glutMainLoop();
}