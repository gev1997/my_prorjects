#ifndef GEOMETRYRENDER_H
#define GEOMETRYRENDER_H

#include <Qt3DRender/QGeometryRenderer>

class GeometryRender : public Qt3DRender::QGeometryRenderer {
public:
    GeometryRender(Qt3DCore::QNode* parent = nullptr) : Qt3DRender::QGeometryRenderer(parent)
    {}
};

#endif // GEOMETRYRENDER_H
