#ifndef OPENGLWINDOW_H_
#define OPENGLWINDOW_H_
#include <QKeyEvent>
#include <QOpenGLWindow>

class OpenGLWindow : public QOpenGLWindow {
  Q_OBJECT
public:
    explicit OpenGLWindow();
    ~OpenGLWindow() override;
    void paintGL() override;
    void initializeGL() override;
    void resizeGL(int _w , int _h) override;

private:
    bool m_initialized;
    void timerEvent(QTimerEvent *) override;
    void keyPressEvent(QKeyEvent *) override;

    void createCube(GLfloat _scale);
    GLuint m_vboPointer;
    int m_width;
    int m_height;
};

#endif
