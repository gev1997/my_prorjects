#include "gldraw.h"

#include <QOpenGLFunctions>
#include <QKeyEvent>

#include <cmath>
#include <iostream>

GLDraw::GLDraw(QWidget* pwgt) : QOpenGLWidget{pwgt}
{}

void GLDraw::initializeGL() {
    QOpenGLFunctions* pFunc = QOpenGLContext::currentContext()->functions();
    pFunc->glClearColor(0, 0, 0, 1);
}

void GLDraw::resizeGL(int width, int height) {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glViewport(0, 0, (GLint)width, (GLint)height);
    glOrtho(0, width, height, 0, -1, 1);
}

void GLDraw::paintGL() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    draw(0, 0, GL_POINTS);
    draw(100, 0, GL_LINES);
    draw(200, 0, GL_LINE_STRIP);
    draw(300, 0, GL_LINE_LOOP);

    draw(0, 100, GL_TRIANGLE_STRIP);
    draw(100, 100, GL_POLYGON);
    draw(200, 100, GL_QUADS);
    draw(300, 100, GL_TRIANGLES);


//    glShadeModel(GL_FLAT);
}

void GLDraw::draw(int xOffset, int yOffset, GLenum type) {
    int n = 8;

    glPointSize(2);
    glBegin(type);
        glColor3f(1, 0, 0);
        for (int i = 0; i < n; ++i) {
            float fAngle = 2 * 3.14 * i / n;

            int x = (int)(50 + cos(fAngle) * 40 + xOffset);
            int y = (int)(50 + sin(fAngle) * 40 + yOffset);

            glVertex2f(x, y);
        }
    glEnd();
}

void GLDraw::keyPressEvent(QKeyEvent *event) {
    std::cerr << event->key();
}

void GLDraw::mousePressEvent(QMouseEvent *event) {

}

void GLDraw::mouseMoveEvent(QMouseEvent *event) {
    std::cerr << event->x() << ' ' << event->y() << std::endl;
}

