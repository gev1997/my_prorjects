#ifndef GLDRAW_H
#define GLDRAW_H

#include <QOpenGLWidget>

class GLDraw : public QOpenGLWidget {
public:
    GLDraw(QWidget* pwgt = nullptr);
    void draw(int xOffset, int yOffset, GLenum type);

protected:
    virtual void initializeGL() override;
    virtual void resizeGL(int, int) override;
    virtual void paintGL() override;

    virtual void keyPressEvent(QKeyEvent *event) override;
    virtual void mousePressEvent(QMouseEvent *event) override;
    virtual void mouseMoveEvent(QMouseEvent *event) override;
};

#endif // GLDRAW_H

