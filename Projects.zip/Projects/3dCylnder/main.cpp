#include <QGuiApplication>
#include <QtWidgets/QWidget>
#include <QScreen>
#include <QSize>
#include <QRenderSettings>

#include <Qt3DInput/QInputAspect>

#include <Qt3DRender/qcamera.h>
#include <Qt3DRender/qcameralens.h>

#include <Qt3DRender/qtechnique.h>
#include <Qt3DExtras/qphongmaterial.h>
#include <Qt3DExtras/qgoochmaterial.h>
#include <Qt3DRender/qeffect.h>
#include <Qt3DRender/qtexture.h>
#include <Qt3DRender/qrenderpass.h>
#include <Qt3DRender/qrenderaspect.h>
#include <Qt3DExtras/qforwardrenderer.h>

#include <Qt3DCore/qentity.h>
#include <Qt3DCore/qtransform.h>
#include <Qt3DCore/qaspectengine.h>

#include <Qt3DExtras/qt3dwindow.h>
#include <Qt3DExtras/qorbitcameracontroller.h>
#include <Qt3DExtras/qfirstpersoncameracontroller.h>

#include <Qt3DRender/QAttribute>
#include <Qt3DRender/QBuffer>
#include <Qt3DRender/QGeometry>

#include <QMesh>

#include <QCullFace>

#include <QSceneLoader>

#include <QPhongAlphaMaterial>

#include "picker.h"

Qt3DCore::QEntity* createEntity(const QVector<QVector3D>& vertices, Qt3DCore::QEntity* rootEntity
                                , void(Pick::*pickSlot)(Qt3DRender::QPickEvent*)
                                ,Qt3DRender::QGeometryRenderer::PrimitiveType type)
{
    const int vertSize = vertices.size();

    //Vertices position
    QByteArray _byte_array;
    _byte_array.resize(3 * vertSize * sizeof(float));

    float* positions = reinterpret_cast<float*>(_byte_array.data());

    for (int i = 0; i < vertSize; ++i) {
        *positions++ = vertices[i].x();
        *positions++ = vertices[i].y();
        *positions++ = vertices[i].z();
    }

    //Geometry
    Qt3DRender::QGeometry* _geometry = new Qt3DRender::QGeometry(rootEntity);

    Qt3DRender::QBuffer* _buffer = new Qt3DRender::QBuffer(_geometry);
    _buffer->setData(_byte_array);

    Qt3DRender::QAttribute* position_attribute = new Qt3DRender::QAttribute(_geometry);
    position_attribute->setName(Qt3DRender::QAttribute::defaultPositionAttributeName());
    position_attribute->setVertexBaseType(Qt3DRender::QAttribute::Float);
    position_attribute->setVertexSize(3);
    position_attribute->setAttributeType(Qt3DRender::QAttribute::VertexAttribute);
    position_attribute->setBuffer(_buffer);
    position_attribute->setByteStride(3 * sizeof(float));
    position_attribute->setCount(vertSize);

     //Add the vertices in the geometry
    _geometry->addAttribute(position_attribute);

    /*
    // connectivity between vertices
    QByteArray indexBytes;
    indexBytes.resize(vertSize * sizeof(unsigned int)); // start to end
    unsigned int *indices = reinterpret_cast<unsigned int*>(indexBytes.data());

    for (unsigned int i = 0; i < static_cast<unsigned int>(vertSize); ++i) {
        *indices++ = i;
    }

    Qt3DRender::QBuffer* indexBuffer = new Qt3DRender::QBuffer(geometry);
    indexBuffer->setData(indexBytes);

    Qt3DRender::QAttribute* indexAttribute = new Qt3DRender::QAttribute(geometry);
    indexAttribute->setVertexBaseType(Qt3DRender::QAttribute::UnsignedInt);
    indexAttribute->setAttributeType(Qt3DRender::QAttribute::IndexAttribute);
    indexAttribute->setBuffer(indexBuffer);
    indexAttribute->setCount(vertSize);
    geometry->addAttribute(indexAttribute); // We add the indices linking the points in the geometry
    */

    //Mesh
    Qt3DRender::QGeometryRenderer* _mesh_render = new Qt3DRender::QGeometryRenderer(rootEntity);
    _mesh_render->setGeometry(_geometry);
    //primitive type
    _mesh_render->setPrimitiveType(type);
    _mesh_render->setVerticesPerPatch(4);

    //Material
    Qt3DExtras::QPhongAlphaMaterial* material = new Qt3DExtras::QPhongAlphaMaterial(rootEntity);
    material->setAlpha(0.5);

    //Entity
    Qt3DCore::QEntity* _entity = new Qt3DCore::QEntity(rootEntity);
    _entity->addComponent(_mesh_render);
    _entity->addComponent(material);

    //Picker
    Qt3DRender::QObjectPicker* _picker = new Qt3DRender::QObjectPicker(_entity);
    _picker->setHoverEnabled(true);
    _picker->setDragEnabled(true);
    _entity->addComponent(_picker);

    Pick *p = new Pick(_entity);
    QObject::connect(_picker, &Qt3DRender::QObjectPicker::pressed, p, pickSlot);

    return _entity;
}

int main(int argc, char **argv) {
    QGuiApplication app(argc, argv);

    Qt3DExtras::Qt3DWindow* view = new Qt3DExtras::Qt3DWindow();
    view->renderSettings()->pickingSettings()->setPickMethod(Qt3DRender::QPickingSettings::PrimitivePicking);
    view->renderSettings()->pickingSettings()->setFaceOrientationPickingMode(Qt3DRender::QPickingSettings::FrontAndBackFace);
    view->renderSettings()->pickingSettings()->setPickResultMode(Qt3DRender::QPickingSettings::NearestPick);

    // Root entity
    Qt3DCore::QEntity* rootEntity = new Qt3DCore::QEntity();
    rootEntity->setObjectName("rootEntity");

    QVector<QVector<QVector3D>> cube = {
        {
            {-1.0f, 1.0f, 1.0f},
            {1.0f, -1.0f, 1.0f},
            {1.0f, 1.0f, 1.0f},

            {-1.0f, 1.0f, 1.0f},
            {-1.0f, -1.0f, 1.0f},
            {1.0f, -1.0f, 1.0f}
        },

        {
            {1.0f, 1.0f, 1.0f},
            {1.0f, -1.0f, -1.0f},
            {1.0f, 1.0f, -1.0f},

            {1.0f, 1.0f, 1.0f},
            {1.0f, -1.0f, 1.0f},
            {1.0f, -1.0f, -1.0f}
        },

        {
            {1.0f, 1.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f},
            {-1.0f, 1.0f, -1.0f},

            {1.0f, 1.0f, -1.0f},
            {1.0f, -1.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f}
        },

        {
            {-1.0f, 1.0f, -1.0f},
            {-1.0f, -1.0f, 1.0f},
            {-1.0f, 1.0f, 1.0f},

            {-1.0f, 1.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f},
            {-1.0f, -1.0f, 1.0f}
        },

        {
            {1.0f, 1.0f, -1.0f},
            {-1.0f, 1.0f, -1.0f},
            {-1.0f, 1.0f, 1.0f},

            {1.0f, 1.0f, 1.0f},
            {1.0f, 1.0f, -1.0f},
            {-1.0f, 1.0f, 1.0f}
        },

        {
            {-1.0f, -1.0f, 1.0f},
            {1.0f, -1.0f, -1.0f},
            {1.0f, -1.0f, 1.0f},

            {-1.0f, -1.0f, 1.0f},
            {-1.0f, -1.0f, -1.0},
            {1.0f, -1.0f, -1.0f}
        }
    };

    QVector<QVector<QVector3D>> cube_outlines = {
        {
            {1.0f, 1.0f, 1.0f},
            {-1.0f, 1.0f, 1.0f},
            {-1.0f, -1.0f, 1.0f},
            {1.0f, -1.0f, 1.0f}
        },

        {
            {1.0f, 1.0f, -1.0f},
            {1.0f, 1.0f, 1.0f},
            {1.0f, -1.0f, 1.0f},
            {1.0f, -1.0f, -1.0f}
        },

        {
            {-1.0f, 1.0f, -1.0f},
            {1.0f, 1.0f, -1.0f},
            {1.0f, -1.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f}
        },

        {
            {-1.0f, 1.0f, 1.0f},
            {-1.0f, 1.0f, -1.0f},
            {-1.0f, -1.0f, -1.0f},
            {-1.0f, -1.0f, 1.0f}
        },

        {
            {-1.0f, 1.0f, -1.0f},
            {-1.0f, 1.0f, 1.0f},

            {1.0f, 1.0f, 1.0f},
            {1.0f, 1.0f, -1.0f},
        },

        {
            {1.0f, -1.0f, 1.0f},
            {-1.0f, -1.0f, 1.0f},
            {-1.0f, -1.0f, -1.0},
            {1.0f, -1.0f, -1.0f}
        }
    };

    for (int i = 0; i < 6; ++i) {
        /*Qt3DCore::QEntity* entity = */createEntity(cube[i], rootEntity, &Pick::pickLine, Qt3DRender::QGeometryRenderer::Triangles);
        /*Qt3DCore::QEntity* entity = *///createEntity(cube_outlines[i], rootEntity, &Pick::pickLine, Qt3DRender::QGeometryRenderer::LineLoop);
    }

    /*
    QVector<QVector3D> vertices = {
        {3.9934, 1.8, 0.15},
        {3.9934, 0, 0.15},
        {0.534417, 0, 0.15},
        {0.359922, 0.641994, 0.15},
        {0.186223, 0.594782, 0.15},
        {0, 1.27992, 0.15},
        {0.173698, 1.32714, 0.15},
        {0.0845209, 1.65523, 0.15},
        {2.79614, 2.39226, 0.15},
        {3.05843, 1.42727, 0.15},
        {3.25143, 1.47972, 0.15},
        {3.16438, 1.8, 0.15}
    };

    QVector<QVector3D> vertices1 = {
        {3.9934, 1.8, 0},
        {3.9934, 0, 0},
        {0.534417, 0, 0},
        {0.359922, 0.641994, 0},
        {0.186223, 0.594782, 0},
        {0, 1.27992, 0},
        {0.173698, 1.32714, 0},
        {0.0845209, 1.65523, 0},
        {2.79614, 2.39226, 0},
        {3.05843, 1.42727, 0},
        {3.25143, 1.47972, 0},
        {3.16438, 1.8, 0}
    };
    */
//    Qt3DCore::QEntity* entity1 = createEntity(vertices1, rootEntity, &Pick::pickLine1);

    // Camera
    Qt3DRender::QCamera *camera = view->camera();
    camera->lens()->setPerspectiveProjection(45.0f, 16.0f/9.0f, 0.1f, 100.0f);
    camera->setPosition(QVector3D(0, 0, 15));
    camera->setUpVector(QVector3D(0, 5, 0));
    camera->setViewCenter(QVector3D(0, 0, 0));

    // For camera controls
    //Orbit
//    Qt3DExtras::QOrbitCameraController* cameraController = new Qt3DExtras::QOrbitCameraController(rootEntity);
//    cameraController->setCamera(camera);

    //First Person
    Qt3DExtras::QFirstPersonCameraController* camController = new Qt3DExtras::QFirstPersonCameraController(rootEntity);
    camController->setCamera(camera);

    /*
    // Cylinder shape data
    Qt3DExtras::QCylinderMesh* mesh = new Qt3DExtras::QCylinderMesh();
    mesh->setRadius(1);
    mesh->setLength(3);
    mesh->setRings(100);
    mesh->setSlices(20);

    // Transform for cylinder
    Qt3DCore::QTransform *transform = new Qt3DCore::QTransform;
    transform->setScale(1.5f);
    transform->setRotation(QQuaternion::fromAxisAndAngle(QVector3D(1, 0, 0), 45.0f));

    // Material
    Qt3DExtras::QGoochMaterial* material = new Qt3DExtras::QGoochMaterial(rootEntity);
    material->setDiffuse(Qt::red);

    // Cylinder
    Qt3DCore::QEntity *cylinder = new Qt3DCore::QEntity(rootEntity);
    cylinder->addComponent(mesh);
    cylinder->addComponent(transform);
    cylinder->addComponent(material);

    Qt3DRender::QObjectPicker* pick = new Qt3DRender::QObjectPicker(cylinder);
    cylinder->addComponent(pick);

    Pick *p = new Pick();
    QObject::connect(pick, &Qt3DRender::QObjectPicker::pressed, p, &Pick::pickCylnder);
    */

    // Set root object of the scene
    view->setRootEntity(rootEntity);
    view->show();

    return app.exec();
}
