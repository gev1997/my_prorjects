#ifndef PICKER_H
#define PICKER_H

#include <QObject>
#include <QEntity>

#include <QObjectPicker>
#include <QPickEvent>

class Pick : public QObject{
    Q_OBJECT

public:
    Pick(QObject* parent = nullptr) : QObject{parent}
    {}

public slots:
    void pickLine(Qt3DRender::QPickEvent* pi) {
        qDebug() << "pick line";

        if (pi->button() == Qt3DRender::QPickEvent::Buttons::MiddleButton && pi->) {
//            pi->entity()->setParent((Qt3DCore::QNode*)nullptr);
            pi->entity()->setEnabled(0);
        }
    }

    void pickLine1(Qt3DRender::QPickEvent* pi) {
        qDebug() << "pick line 1";
    }

    void pickCylnder(Qt3DRender::QPickEvent* pi) {
        qDebug() << "pick cylnder";
    }
};

#endif // PICKER_H
