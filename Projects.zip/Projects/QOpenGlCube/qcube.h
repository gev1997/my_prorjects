#ifndef QCUBE_H
#define QCUBE_H

#include <QOpenGLWidget>

class QCube : public QOpenGLWidget {
public:
    QCube(QWidget* pwgt = nullptr);

protected:
    virtual void initializeGL() override;
    virtual void resizeGL(GLint, GLint) override;
    virtual void paintGL() override;

    virtual void mousePressEvent(QMouseEvent*) override;
    virtual void mouseMoveEvent(QMouseEvent*) override;
    virtual void wheelEvent(QWheelEvent*) override;

    GLuint draw_cube(GLfloat);

private:
    GLuint m_nCube;
    GLfloat m_xRotate;
    GLfloat m_yRotate;
    QPoint m_ptPosition;

    GLfloat m_scale;
    bool m_is_line;

    QVector<GLfloat> m_vertices = {
        -1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f, -1.0f, 1.0f,
        -1.0f, -1.0f, 1.0f,

        1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, -1.0f,
        1.0f, -1.0f, -1.0f,
        1.0f, -1.0f, 1.0f,

        1.0f, 1.0f, -1.0f,
        -1.0f, 1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
        1.0f, -1.0f, -1.0f,

        -1.0f, 1.0f, -1.0f,
        -1.0f, 1.0f, 1.0f,
        -1.0f, -1.0f, 1.0f,
        -1.0f, -1.0f, -1.0f,

        -1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, 1.0f,
        1.0f, 1.0f, -1.0f,
        -1.0f, 1.0f, -1.0f,

        -1.0f, -1.0f, 1.0f,
        1.0f, -1.0f, 1.0f,
        1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0
        };
};

#endif // QCUBE_H
