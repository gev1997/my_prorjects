# 3D Object in OpenGl

3D հարթությունում մարմին պատկերելու համար, մենք կօգտվենք Qt ծրագրից։

<p><img src="img/object.png"></p>

Qt֊ում OpenGl֊ից օգտվելու համար, պետք է պրոեկտին ավելացնել համապատասխան գրադարանը․

    #include «QOpenGLWidget»

QOpenGLWidget կլասը օգտագործելու համար, պետք է նրանից public ժառանգել և վերասահմանել նրա վիրտուալ
ֆունկցիաներից երեքը՝

    initializeGL()
    resizeGL(GLint, GLint)
    paintGL()

Կլասի նկարագրությունը հետևյալն է

    #include <QOpenGLWidget>

    class custom_draw : public QOpenGLWidget {
        public:
        custom_draw(QWidget* pwgt = nullptr);

        protected:
        virtual void initializeGL() override;
        virtual void resizeGL(GLint, GLint) override;
        virtual void paintGL() override;

        virtual void mousePressEvent(QMouseEvent*) override;
        virtual void mouseMoveEvent(QMouseEvent*) override;
        virtual void wheelEvent(QWheelEvent*) override;

        GLuint draw();

        private:
        GLuint m_nDraw;
        GLfloat m_xRotate;
        GLfloat m_yRotate;
        QPoint m_ptPosition;

        GLfloat m_scale;
        bool m_is_line;

        QVector<QVector<GLfloat>> m_vertices;
    };

m_vertices վեկտորը ինիցիալիզացնում ենք vertex_parser ֆունկցիայի վերադարձրած արժեքով, որը
մեր մարմնի պատկերման կոորդինատներն պարունակող զանգված է։

Որպես արգումենտ ստանում է տող, որը հղում է, դեպի կետերի կոորդինատները պարունակող տեքստային ֆայլը։

    Coordinates

    A Red = (x:3.9934, y:1.8,z:0.15)
    B Red = (x:3.993395, y:0,z:0.15)
    C Red = (x:0.534417, y:0,z:0.15)
    D Red = (x:0.359922, y:0.641994,z:0.15)
    E Red = (x:0.186223, y:0.594782,z:0.15)
    F Red = (x:0, y:1.27992,z:0.15)
    G Red = (x:0.173698, y:1.32714,z:0.15)
    H Red = (x:0.0845209, y:1.65523,z:0.15)
    I Red = (x:2.79614, y:2.39226,z:0.15)
    J Red = (x:3.05843, y:1.42727,z:0.15)
    K Red = (x:3.25143, y:1.47972,z:0.15)
    L Red = (x:3.16438, y:1.8,z:0.15)

    A Green = (x:3.9934, y:1.8,z:0)
    B Green = (x:3.993395, y:0,z:0)
    C Green = (x:0.534417, y:0,z:0)
    D Green = (x:0.359922, y:0.641994,z:0)
    E Green = (x:0.186223, y:0.594782,z:0)
    F Green = (x:0, y:1.27992,z:0)
    G Green = (x:0.173698, y:1.32714,z:0)
    H Green = (x:0.0845209, y:1.65523,z:0)
    I Green = (x:2.79614, y:2.39226,z:0)
    J Green = (x:3.05843, y:1.42727,z:0)
    K Green = (x:3.25143, y:1.47972,z:0)
    L Green = (x:3.16438, y:1.8,z:0)

#### initializeGL()
Ծրագիրը սկսելուց կանչվում է և ինիցիալիզացվում մի քանի պարամետր՝

    void custom_draw::initializeGL() {
        QOpenGLFunctions* pFunc = QOpenGLContext::currentContext()->functions();

        pFunc->glClearColor(0, 0, 0, 1);
        pFunc->glEnable(GL_DEPTH_TEST);

        m_nDraw = draw();
    }

Սահմանում ենք էկրանի գույնը և միացնում էկրանի խորության ստուգման ռեժիմը։ Պատկերում ենք մարմինը։


#### resizeGL()
Որպես պարամետր ստանում է էկրանի չափսերը՝ երկարությունը և լայնությունը։

    void custom_draw::resizeGL(GLint width, GLint height) {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glViewport(0, 0, width, height);

        glFrustum(-1.0, 1.0, -1.0, 1.0, 2, 50.0);
        glTranslatef(0, -5, -15);
    }

Այն կանչվում է այն դեպքում, երբ էկրանի չափսերը փոխում ենք։


#### paintGL()
Այն կանչվում է ամեն անգամ էկրանը թարմացնելուց։

    void custom_draw::paintGL() {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        if (m_is_line) {
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        } else {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        }

        glTranslatef(0.0, 0.0, -6);
        glRotatef(m_xRotate, 1.0, 0.0, 0.0);
        glRotatef(m_yRotate, 0.0, 1.0, 0.0);
        glScalef(m_scale, m_scale, m_scale);

        glCallList(m_nDraw);
    }

Մաքրում ենք էկրանին տպված հին պատկերը, սահմանում է մատրիցի պատկերման ռեժիմը և մատրիցը բերում սկզբնական վիճակի։

m_is_line բուլյանի արժեքից կախված, (որը փոխվում է մկնիկի աջ կոճակը սեղմելուց), պատկերը դարձնում ենք ներկված կամ ոչ ներկված։

glTranslatef(0.0, 0.0, -6)֊ի միջոցով մատրիցը Z հարթության ուղղությամբ ետ ենք տանում նշված չափսով։

glRotatef ֆունկցիան օգտագործում ենք, մատրիցը պտտելու համար, xRotate և yRotate պարամետրեր են, որոնք օգտագործում ենք պատկերը պտտելուց, մկնիկի միջոցով։

glScalef(m_scale, m_scale, m_scale)֊ի միջոցով փոխում ենք մատրիցի պատկերման մասշտաբը։


### draw()
    GLuint custom_draw::draw() {
        GLuint n_gen_lists = glGenLists(1);

        glNewList(n_gen_lists, GL_COMPILE);
        glColor3f(0.5, 0.4, 0.4);

        glEnableClientState(GL_VERTEX_ARRAY);
            glVertexPointer(3, GL_FLOAT, 0, m_vertices[0].data());
            glDrawArrays(GL_POLYGON, 0, 12);

            glVertexPointer(3, GL_FLOAT, 0, m_vertices[1].data());
            glDrawArrays(GL_POLYGON, 0, 12);
        glDisableClientState(GL_VERTEX_ARRAY);

        for (int i = 0; i < m_vertices[0].size() - 3; i += 3) {
            glBegin(GL_QUADS);
                glVertex3f(m_vertices[0][i], m_vertices[0][i + 1], m_vertices[0][i + 2]);
                glVertex3f(m_vertices[0][i + 3], m_vertices[0][i + 4], m_vertices[0][i + 5]);
                glVertex3f(m_vertices[1][i + 3], m_vertices[1][i + 4], m_vertices[1][i + 5]);
                glVertex3f(m_vertices[1][i], m_vertices[1][i + 1], m_vertices[1][i + 2]);
            glEnd();
        }

        int size = m_vertices[0].size();

        glBegin(GL_QUADS);
            glVertex3f(m_vertices[0][0], m_vertices[0][1], m_vertices[0][2]);
            glVertex3f(m_vertices[0][size - 3], m_vertices[0][size - 2], m_vertices[0][size - 1]);
            glVertex3f(m_vertices[1][size - 3], m_vertices[1][size - 2], m_vertices[1][size - 1]);
            glVertex3f(m_vertices[1][0], m_vertices[1][1], m_vertices[1][2]);
        glEnd();

        glEndList();

        return n_gen_lists;
    }

Առաջին տողում glGenLists(1) ֆունկցիան վերադարձնում է ազատ իդենտիֆիկատորի համարը։
Այդ արժեքը պահում ենք n_gen_lists փոփոխականի մեջ։ n_gen_lists֊ի արժեքն էլ իր հերթին վերադարձվում է
draw_cube֊ից, և վերագրվում m_nCube անդամ փոփոխականին, որի արժեքը փոխանցում ենք glCallList֊ին։
glCallList֊ի շնորհիվ արագացնում ենք մարմինների պատկերումը, քանի որ glCallList֊ը օգտվում է նախկինում
կրկին պատկերված և վիդեոպրոցեսորի cache-ում պահված տվյալներից, և ցուցադրում այն, խուսափելով կրկին պատկերելուց։

Ստեղծում ենք նոր լիստ, օգտագործելով իդենտիֆիկատորի համարը։

    glNewList(n_gen_lists, GL_COMPILE);

Սահմանում ենք պատկերի գույնը։

    glColor3f(0.0, 0.4, 0.0)

glVertexPointer֊ին փոխանցում ենք m_vertices.data(), որը float տիպի զանգված է, որտեղ նշված են կետերի կոորդինատները։

glDrawArrays֊ին հայտնում ենք, թե ինչ ձևի պատկեր ենք ուզում նկարել, օրինակում օգտագործվում է
GL_POLYGON, որը իրենից ներկայացնում է բազմանկյուն։

glEndList() ֆունկցիան կանչելով հայտնում ենք լիստի պատկերման ավարտը։


### mousePressEvent()
mousePressEvent()֊ը վիրտուալ վերասահմանված ֆունկցիա է, որը կանչվում է ամեն անգամ մկնինի կլիկի ժամանակ։

    void custom_draw::mousePressEvent(QMouseEvent* event) {
        if (event->button() == Qt::RightButton) {
            m_is_line = !m_is_line;
            update();
        }

        m_ptPosition = event->pos();
    }

Որպես պարամետր ստանում է QMouseEvent կլասի event օբյեկտ։ QMouseEvent կլասը ստեղծված է մկնիկից ստացվող տվյալները
մշակելու և օգտագործելու համար։

update() ֆունկցիան կանչում ենք, էկրանը թարմացնելու համար։

Ամեն կլիկի ժամանակ, պահում ենք մկնիկի սլաքի կոորդինատները QPoint տիպի ptPosition օբյեկտում։


### mouseMoveEvent()
mouseMoveEvent()֊ը վիրտուալ վերասահմանված ֆունկցիա է, որը կանչվում է մկնիկի կուրսորը շարժելուց։

    void custom_draw::mouseMoveEvent(QMouseEvent* event) {
        m_xRotate += 180 * (GLfloat)(event->y() - m_ptPosition.y()) / height();
        m_yRotate += 180 * (GLfloat)(event->x() - m_ptPosition.x()) / width();
        update();

        m_ptPosition = event->pos();
    }

Որպես պարամետր ստանում է QMouseEvent կլասի event օբյեկտ։

mouseMoveEvent() ֆունկցիայում ամեն անգամ փոխում ենք xRotate և yRotate պարամետրները, որոնց արժեքներից կախված,
մատրիցը պտտվում է X և Y առանցքների շուրջ։

    xRotate += 180 * (GLfloat)(event->y() - ptPosition.y()) / height();
    yRotate += 180 * (GLfloat)(event->x() - ptPosition.x()) / width();

որտեղ event֊ը դա QMouseEvent տիպի օբյեկտ է, event->x() և event->y() մկնիկի սլաքի կոորդինատներն են,
տվյալ պահինն, իսկ ptPosition մկնիկի սլաքի դրիքն է, կոճակը սեղմելու պահին։

width() և height() համապատասխանաբար էկրանի լայնությունը և բարձրությունը։

update() ֆունկցիան կանչում ենք, էկրանը թարմացնելու համար։


### wheelEvent()
wheelEvent()-վիրտուալ վերասահմանված ֆունկցիա է, որը կանչվում է մկնիկի անվակոճակը պտտելուց։

    void custom_draw::wheelEvent(QWheelEvent* event) {
        if (event->angleDelta().y() > 0) {
            m_scale += 0.1;
        } else if (event->angleDelta().y() < 0) {
            m_scale -= 0.1;
        }

        update();
    }

Ստուգում ենք պտտման ուղղությունը, որից կախված ավելացնում կամ պակասեցնում ենք m_scale
փոփոխականը, որը օգտագործվում է մատրիցի պատկերման մասշտաբը փոխելու համար։

update() ֆունկցիան կանչում ենք, էկրանը թարմացնելու համար։


## main.cpp

main.cpp compilation unit֊ում ստեղծում ենք QOpenGLWidget կլասից ժառանգած մեր կլասի օբյեկտ։

    #include "custom_draw.h"

    #include <QApplication>

    int main(int argc, char *argv[]) {
        QApplication a(argc, argv);

        custom_draw window;

        window.resize(900, 900);
        window.show();

        return a.exec();
    }

Փոխում ենք էկրանի չափսերը

    window.resize(width, height)

 և ցուցադրում էկրանը

    window.show();
