#include "custom_draw.h"

#include <QApplication>

int main(int argc, char *argv[]) {
    QApplication a(argc, argv);

    custom_draw w;

    w.resize(900, 900);
    w.show();

    return a.exec();
}
